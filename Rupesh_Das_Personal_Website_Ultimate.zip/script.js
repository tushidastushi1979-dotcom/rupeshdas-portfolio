const menu=document.querySelector('.menu');
const nav=document.querySelector('.nav nav');
if(menu){menu.addEventListener('click',()=>{const open=nav.classList.toggle('open');nav.style.display=open?'flex':'';if(open){nav.style.position='absolute';nav.style.top='82px';nav.style.left='0';nav.style.right='0';nav.style.padding='22px 7%';nav.style.background='#090909';nav.style.flexDirection='column';nav.style.gap='18px';}});}
const bar=document.querySelector('.progress');
window.addEventListener('scroll',()=>{const max=document.documentElement.scrollHeight-innerHeight;bar.style.width=(max?scrollY/max*100:0)+'%';},{passive:true});
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')}),{threshold:.12});
document.querySelectorAll('.reveal-section').forEach(e=>io.observe(e));
document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener('click',()=>{if(nav.classList.contains('open')){nav.classList.remove('open');nav.style.display='none'}}));
